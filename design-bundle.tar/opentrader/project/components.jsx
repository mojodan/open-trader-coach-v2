const { useState, useEffect, useMemo, useRef } = React;

// ---------- Theme Toggle ----------
function ThemeToggle({ theme, onToggle }) {
  const isDark = theme === "dusk";
  return (
    <button
      className={`theme-toggle ${isDark ? "dark" : "light"}`}
      onClick={onToggle}
      aria-label={isDark ? "Switch to light theme" : "Switch to dark theme"}
      title={isDark ? "Light mode" : "Dark mode"}
    >
      <span className="toggle-track">
        <span className="toggle-thumb">
          {isDark ? (
            <svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor">
              <path d="M21 12.79A9 9 0 1 1 11.21 3a7 7 0 0 0 9.79 9.79z"/>
            </svg>
          ) : (
            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <circle cx="12" cy="12" r="5"/>
              <line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/>
              <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
              <line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/>
              <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
            </svg>
          )}
        </span>
      </span>
    </button>
  );
}

// ---------- Header ----------
function Header({ sessions, questions, theme, onThemeToggle }) {
  return (
    <header className="app-header">
      <div className="brand">
        <span className="brand-dot" />
        <span className="brand-name">OpenTrader</span>
        <span className="brand-sub">Coach</span>
      </div>
      <div className="stats">
        <div className="stat">
          <div className="stat-num">{sessions}</div>
          <div className="stat-label">Sessions</div>
        </div>
        <div className="stat-divider" />
        <div className="stat">
          <div className="stat-num">{questions.toLocaleString()}</div>
          <div className="stat-label">Questions</div>
        </div>
        <div className="stat-divider" />
        <ThemeToggle theme={theme} onToggle={onThemeToggle} />
      </div>
    </header>
  );
}

// ---------- Search ----------
function SearchBar({ value, onChange, resultCount, query }) {
  const ref = useRef(null);
  useEffect(() => {
    const handler = (e) => {
      if (e.key === "/" && document.activeElement !== ref.current) {
        e.preventDefault();
        ref.current?.focus();
      }
      if (e.key === "Escape" && document.activeElement === ref.current) {
        ref.current.blur();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);
  return (
    <div className="search-wrap">
      <div className="search">
        <svg className="search-icon" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="11" cy="11" r="7" />
          <path d="m20 20-3.5-3.5" />
        </svg>
        <input
          ref={ref}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Search sessions, topics, traders..."
          spellCheck={false}
        />
        <kbd className="kbd">/</kbd>
      </div>
      {query && (
        <div className="search-meta">
          {resultCount} {resultCount === 1 ? "match" : "matches"} for “{query}”
        </div>
      )}
    </div>
  );
}

// ---------- Filter chips ----------
const FILTERS = [
  { id: "all", label: "All" },
  { id: "chart", label: "Chart Review" },
  { id: "trade", label: "Trade Review" },
  { id: "mindset", label: "Mindset" },
  { id: "setup", label: "Setups" },
];

function FilterRow({ active, onChange }) {
  return (
    <div className="filters">
      {FILTERS.map((f) => (
        <button
          key={f.id}
          className={`chip ${active === f.id ? "chip-on" : ""}`}
          onClick={() => onChange(f.id)}
        >
          {f.label}
        </button>
      ))}
    </div>
  );
}

// ---------- Highlight ----------
function Highlight({ text, query }) {
  if (!query) return <>{text}</>;
  const parts = text.split(new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "gi"));
  return (
    <>
      {parts.map((p, i) =>
        p.toLowerCase() === query.toLowerCase() ? (
          <mark key={i}>{p}</mark>
        ) : (
          <span key={i}>{p}</span>
        )
      )}
    </>
  );
}

// ---------- Question row ----------
function QuestionRow({ q, onPlay, playing, query }) {
  return (
    <div className={`q-row ${playing ? "q-playing" : ""}`}>
      <button className="ts" onClick={() => onPlay(q)} title="Jump to moment">
        <svg viewBox="0 0 24 24" width="11" height="11" fill="currentColor" className="ts-play">
          <path d="M8 5v14l11-7z" />
        </svg>
        <span>{q.t}</span>
      </button>
      <div className="q-body">
        <div className="q-text"><Highlight text={q.q} query={query} /></div>
        <div className="q-meta">
          <span className="asker">{q.asker}</span>
          <span className="q-sep">·</span>
          <button className="q-link">Open transcript</button>
          <button className="q-link">Copy link</button>
        </div>
      </div>
    </div>
  );
}

// ---------- Session block ----------
function SessionBlock({ session, query, onPlay, playingId }) {
  const [expanded, setExpanded] = useState(true);
  return (
    <section className="session">
      <header className="session-head">
        <button className="session-toggle" onClick={() => setExpanded(!expanded)}>
          <svg className={`caret ${expanded ? "open" : ""}`} viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            <path d="m9 18 6-6-6-6" />
          </svg>
          <span className="session-date">{session.date}</span>
        </button>
        <span className="session-title">{session.title}</span>
        <span className="session-dot" />
        <span className="session-duration">{session.duration}</span>
        <span className="session-count">
          {session.questions.length} {session.questions.length === 1 ? "question" : "questions"}
        </span>
      </header>
      {expanded && (
        <div className="session-body">
          {session.questions.map((q, i) => (
            <QuestionRow
              key={i}
              q={q}
              query={query}
              onPlay={onPlay}
              playing={playingId === `${session.iso}-${i}`}
            />
          ))}
        </div>
      )}
    </section>
  );
}

// ---------- Player strip ----------
function PlayerStrip({ playing, onClose }) {
  const [pos, setPos] = useState(0);
  useEffect(() => {
    if (!playing) return;
    setPos(0);
    const id = setInterval(() => setPos((p) => (p + 0.4) % 100), 80);
    return () => clearInterval(id);
  }, [playing]);
  if (!playing) return null;
  return (
    <div className="player">
      <div className="player-inner">
        <button className="player-btn" aria-label="Pause">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M6 5h4v14H6zM14 5h4v14h-4z" /></svg>
        </button>
        <div className="player-meta">
          <div className="player-title">{playing.session} · {playing.t}</div>
          <div className="player-q">{playing.q}</div>
        </div>
        <div className="player-progress"><div className="player-fill" style={{ width: `${pos}%` }} /></div>
        <button className="player-close" onClick={onClose} aria-label="Close">×</button>
      </div>
    </div>
  );
}

// ---------- Tweaks ----------
function TweaksPanel({ tweaks, setTweaks, onClose }) {
  const set = (k, v) => setTweaks({ ...tweaks, [k]: v });
  return (
    <div className="tweaks">
      <div className="tweaks-head">
        <span>Tweaks</span>
        <button onClick={onClose}>×</button>
      </div>
      <div className="tweaks-body">
        <div className="tweak-group">
          <div className="tweak-label">Theme</div>
          <div className="tweak-row">
            {["paper", "cream", "sage", "dusk"].map((t) => (
              <button
                key={t}
                className={`swatch swatch-${t} ${tweaks.theme === t ? "on" : ""}`}
                onClick={() => set("theme", t)}
                title={t}
              >
                <span className="swatch-name">{t}</span>
              </button>
            ))}
          </div>
        </div>
        <div className="tweak-group">
          <div className="tweak-label">Body font</div>
          <div className="tweak-row">
            {[
              { id: "geist", label: "Geist" },
              { id: "ibm", label: "IBM Plex" },
              { id: "source", label: "Source Serif" },
            ].map((f) => (
              <button
                key={f.id}
                className={`pill ${tweaks.font === f.id ? "on" : ""}`}
                onClick={() => set("font", f.id)}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
        <div className="tweak-group">
          <div className="tweak-label">Density</div>
          <div className="tweak-row">
            {["cozy", "comfortable", "airy"].map((d) => (
              <button
                key={d}
                className={`pill ${tweaks.density === d ? "on" : ""}`}
                onClick={() => set("density", d)}
              >
                {d}
              </button>
            ))}
          </div>
        </div>
        <div className="tweak-group">
          <div className="tweak-label">Timestamp style</div>
          <div className="tweak-row">
            {["pill", "mono", "ghost"].map((s) => (
              <button
                key={s}
                className={`pill ${tweaks.tsStyle === s ? "on" : ""}`}
                onClick={() => set("tsStyle", s)}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
        <div className="tweak-group">
          <div className="tweak-label">Accent hue</div>
          <input
            type="range" min="10" max="360" step="1"
            value={tweaks.hue}
            onChange={(e) => set("hue", +e.target.value)}
          />
          <div className="tweak-hue">
            <div className="hue-swatch" style={{ background: `oklch(0.62 0.12 ${tweaks.hue})` }} />
            <span>hue {tweaks.hue}°</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- Recently Viewed Sidebar ----------
// Mock server fetch — replace the URL with your real endpoint.
// Expected response: array of ["YYYYMMDD", "MM:SS", "question text"]
async function fetchRecentlyViewed() {
  // Simulated server delay + mock data
  await new Promise(r => setTimeout(r, 420));
  return [
    ["20260311", "07:32", "Can you share the best Zone Fade opportunities that were available over the past week along with the context that made them good?"],
    ["20260311", "00:09", "Chart Review (March 10th): I missed the Long at Pre-Market Support which was also a Bias Changing Zone. Was this an automatic Fade setup?"],
    ["20260304", "12:37", "What were the best trade setups from this past week that we should not be missing, and why?"],
    ["20260225", "16:04", "Can you share your take on the best Zone Fade setups over the past week and the context that went into them?"],
    ["20260225", "00:10", "Chart Review (February 23rd): Can you explain your thinking behind the first scale on Monday's trade that was 3R?"],
    ["20260218", "35:10", "Is there a checklist you use before taking a setup in the last hour of the session? My stats are noticeably worse after 2pm."],
    ["20260218", "19:48", "Could you walk through how you journal a trade that went right for the wrong reasons? I'm struggling to separate process from outcome."],
    ["20260211", "22:40", "Walk through a day where none of your A+ setups triggered — what do you actually do with your time instead of forcing trades?"],
    ["20260211", "03:55", "How do you adjust your bias when overnight futures gap against the prior day's trend but the pre-market volume is light?"],
    ["20260218", "02:14", "When I'm on a losing streak, I tend to size down to the point where a winner barely recovers a prior loss. How do you recommend thinking about position sizing after 2–3 consecutive losses?"],
  ];
}

function formatDate(raw) {
  // "20260311" → "2026-03-11"
  return `${raw.slice(0,4)}-${raw.slice(4,6)}-${raw.slice(6,8)}`;
}

function RecentlyViewed({ onPlay }) {
  const [rows, setRows] = useState(null);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    fetchRecentlyViewed().then(setRows);
  }, []);

  return (
    <section className="session">
      <header className="session-head">
        <button className="session-toggle" onClick={() => setExpanded(!expanded)}>
          <svg className={`caret ${expanded ? "open" : ""}`} viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            <path d="m9 18 6-6-6-6" />
          </svg>
          <span className="session-date">Recently Viewed</span>
        </button>
        <span className="session-count" style={{ marginLeft: "auto" }}>
          {rows ? `${rows.length} entries` : "…"}
        </span>
      </header>
      {expanded && (
        <div className="session-body">
          {rows === null ? (
            <div className="sidebar-loading" style={{ padding: "10px 14px" }}>
              {[...Array(5)].map((_, i) => (
                <div key={i} className="skel-row" style={{ width: `${55 + (i % 3) * 15}%`, animationDelay: `${i * 60}ms` }} />
              ))}
            </div>
          ) : rows.length === 0 ? (
            <div className="sidebar-empty">No recent activity</div>
          ) : (
            rows.map((row, i) => (
              <div
                key={i}
                className="rv-inline-row"
                onClick={() => onPlay({ t: row[1], q: row[2], date: formatDate(row[0]) })}
              >
                <button className="ts" tabIndex={-1}>
                  <svg viewBox="0 0 24 24" width="11" height="11" fill="currentColor" className="ts-play"><path d="M8 5v14l11-7z" /></svg>
                  <span>{row[1]}</span>
                </button>
                <div className="rv-inline-body">
                  <span className="rv-inline-date">{formatDate(row[0])}</span>
                  <span className="rv-inline-q">{row[2]}</span>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </section>
  );
}

// ---------- App ----------
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "paper",
  "font": "geist",
  "density": "comfortable",
  "tsStyle": "pill",
  "hue": 35
}/*EDITMODE-END*/;

function App() {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const [playing, setPlaying] = useState(null);
  const [showTweaks, setShowTweaks] = useState(false);
  const [tweaks, setTweaks] = useState(() => {
    try {
      const saved = localStorage.getItem("ot-tweaks");
      if (saved) return { ...TWEAK_DEFAULTS, ...JSON.parse(saved) };
    } catch {}
    return TWEAK_DEFAULTS;
  });

  // persist tweaks
  useEffect(() => {
    localStorage.setItem("ot-tweaks", JSON.stringify(tweaks));
    document.documentElement.dataset.theme = tweaks.theme;
    document.documentElement.dataset.font = tweaks.font;
    document.documentElement.dataset.density = tweaks.density;
    document.documentElement.dataset.ts = tweaks.tsStyle;
    document.documentElement.style.setProperty("--hue", tweaks.hue);
  }, [tweaks]);

  // edit-mode host integration
  useEffect(() => {
    const handler = (e) => {
      if (e.data?.type === "__activate_edit_mode") setShowTweaks(true);
      if (e.data?.type === "__deactivate_edit_mode") setShowTweaks(false);
    };
    window.addEventListener("message", handler);
    window.parent.postMessage({ type: "__edit_mode_available" }, "*");
    return () => window.removeEventListener("message", handler);
  }, []);

  useEffect(() => {
    window.parent.postMessage({
      type: "__edit_mode_set_keys",
      edits: tweaks
    }, "*");
  }, [tweaks]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const matchesFilter = (session, question) => {
      if (filter === "all") return true;
      const txt = (session.title + " " + question.q).toLowerCase();
      if (filter === "chart") return txt.includes("chart review");
      if (filter === "trade") return txt.includes("trade review") || txt.includes("trade setup");
      if (filter === "mindset") return /focus|frustrat|mindset|bored|fomo|streak|journal/i.test(txt);
      if (filter === "setup") return /setup|zone fade|support|resistance|pre-market/i.test(txt);
      return true;
    };
    return window.SESSIONS
      .map((s) => ({
        ...s,
        questions: s.questions.filter(
          (ques) =>
            matchesFilter(s, ques) &&
            (!q ||
              ques.q.toLowerCase().includes(q) ||
              ques.asker.toLowerCase().includes(q) ||
              s.title.toLowerCase().includes(q) ||
              s.date.toLowerCase().includes(q))
        ),
      }))
      .filter((s) => s.questions.length > 0);
  }, [query, filter]);

  const totalMatches = filtered.reduce((a, s) => a + s.questions.length, 0);

  const handlePlay = (q) => {
    const session = window.SESSIONS.find((s) => s.questions.includes(q));
    setPlaying({ ...q, session: session.title, sessionIso: session.iso });
  };

  return (
    <div className="shell">
      <Header
        sessions={461}
        questions={3925}
        theme={tweaks.theme}
        onThemeToggle={() => setTweaks(t => ({ ...t, theme: t.theme === "dusk" ? "paper" : "dusk" }))}
      />
      <div className="sticky-bar">
        <SearchBar
          value={query}
          onChange={setQuery}
          resultCount={totalMatches}
          query={query}
        />
        <FilterRow active={filter} onChange={setFilter} />
      </div>
      <main className="list">
        <RecentlyViewed onPlay={handlePlay} />
        {filtered.length === 0 ? (
          <div className="empty">
            <div className="empty-big">No questions match</div>
            <div className="empty-sub">Try a different keyword or clear filters.</div>
            <button className="btn-ghost" onClick={() => { setQuery(""); setFilter("all"); }}>Reset</button>
          </div>
        ) : (
          filtered.map((s) => (
            <SessionBlock
              key={s.iso}
              session={s}
              query={query}
              onPlay={handlePlay}
              playingId={playing ? `${playing.sessionIso}-${s.questions.indexOf(playing)}` : null}
            />
          ))
        )}
      </main>
      <PlayerStrip playing={playing} onClose={() => setPlaying(null)} />
      {showTweaks && (
        <TweaksPanel
          tweaks={tweaks}
          setTweaks={setTweaks}
          onClose={() => setShowTweaks(false)}
        />
      )}
    </div>
  );
}

Object.assign(window, { App });
